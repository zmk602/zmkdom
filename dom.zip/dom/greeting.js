export default function sayHello(name) {
  return `你好, ${name}!`;
}

export function sayGoodbye(name) {
  return `再见, ${name}!`;
}